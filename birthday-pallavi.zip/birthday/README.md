# 🎂 Happy Birthday Pallavi — Website

A grand, premium birthday website built with pure HTML, CSS & Vanilla JavaScript.

## Project Structure

```
birthday/
├── index.html
├── style.css
├── app.js
├── README.md
└── assets/
    ├── images/
    │   ├── 1.jpg   ← Hero photo (add your photo here)
    │   └── 2.jpg   ← Memories photo (add your photo here)
    └── music/
        └── 3.mp3   ← Background music (add your music here)
```

## Setup Instructions

1. **Add your assets** — Place the photos and music file into the `assets/` folders using the exact filenames above.
2. **Open locally** — Open `index.html` in any browser. No server needed.
3. **Deploy to GitHub Pages**:
   - Push the entire folder to a GitHub repository
   - Go to **Settings → Pages → Source → main branch / root**
   - Your site will be live at `https://yourusername.github.io/repo-name`

## Features

- 🎆 Cinematic loading animation (2 seconds)
- 🎇 Fireworks on page reveal & final surprise
- 🎊 Confetti burst from both sides
- 🎈 Continuously rising balloons
- ✨ Soft glowing particles
- 🌸 Floating flower petals
- 🎵 Background music with floating control button
- 🖼 Glassmorphism photo frame for memories
- ✍️ Realistic typewriter letter animation
- ❤️ Floating hearts in the finale
- 📱 Mobile-first responsive design
- ♿ Respects `prefers-reduced-motion`

## Notes

- Music starts on first user interaction (browser autoplay policy)
- The letter typewriter begins when the letter section scrolls into view
- Click "One Last Surprise 🎁" for the grand finale fireworks show
